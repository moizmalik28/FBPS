# Windows deployment and release acceptance

**Release status: candidate for Windows acceptance testing, not production-approved.** All automated SQLite tests pass, but Visual Studio execution, clean-Windows application execution and physical printer acceptance have not been performed in the Linux workspace.

## Build and publish in Visual Studio 2022

1. Install Visual Studio 2022 17.11 or newer with **.NET desktop development** and a supported patched .NET 8 SDK. The checked-in `global.json` permits the latest installed .NET 8 feature band; the cloud build used SDK **8.0.426**.
2. Open `FBPS.sln`. Restore NuGet dependencies and build **Release**. Run all tests in Test Explorer; no financial, receipt, allocation or persistence failure is acceptable.
3. Right-click `FBPS.WinForms` → **Publish**. Select the checked-in **Windows-x64** folder profile (`Properties/PublishProfiles/Windows-x64.pubxml`). Verify Release, `net8.0-windows`, `win-x64`, **self-contained**, no trimming and no single-file bundling. Publish.
4. Output is `artifacts/win-x64/`. Copy the **whole folder**, not just the executable. The application entry point is `FBPS.WinForms.exe`.

Equivalent command successfully executed in Linux (cross-publish, not Visual Studio execution):

```powershell
dotnet publish src/FBPS.WinForms/FBPS.WinForms.csproj -p:PublishProfile=Windows-x64
```

The resulting folder includes **Microsoft.NETCore.App 8.0.32**, **Microsoft.WindowsDesktop.App 8.0.32**, the Windows x64 native SQLite library and required runtime binaries. A separate .NET runtime or SDK is not needed for this self-contained artifact. Use a supported Windows x64 desktop environment (Windows 11 x64 recommended). Native dependencies and actual WinForms execution must still be verified on the school's clean Windows target. Re-publish with maintained SDK/runtime patches as part of updates; self-contained deployments do not inherit a separately installed runtime's patches.

A framework-dependent alternative requires **.NET 8 Windows Desktop Runtime x64**, not only the base .NET runtime:

```powershell
dotnet publish src/FBPS.WinForms -c Release -r win-x64 --self-contained false -o artifacts/win-x64-framework-dependent
```

This alternative was not the tested publish profile. No installer, code signing or automatic updater is included. The prepared ZIP is a portable folder deployment; the deployment administrator must manage installation-folder permissions and updates.

## Storage and update procedure

Default database: `%LOCALAPPDATA%\FutureBuildersPublicSchool\school.db`, scoped to the Windows user. Configure an absolute persistent local path with `FBPS_DATABASE_PATH` when the school needs a designated account/folder. Do not put it on a network share or in the application/build output. `bin/Debug`, `bin/Release`, relative paths and the running app output directory are rejected.

One application instance per database is enforced by a held `.app.lock` file handle. Do not manually remove/replace this lock while FBPS is running. External database editors must be closed during restore and normal school operation.

Before an upgrade: create and verify a backup; close FBPS; retain the previous application release; replace the application folder only; launch with the same database path. Startup applies migrations without resetting the database. Never delete the database or replace migrations with `EnsureCreated`. Populated-schema migration tests verify preservation and rollback of invalid upgrades. Restores require matching schema versions; retain the corresponding old release when retaining old backups.

## Clean Windows gate — must be completed before live use

Record tester, date, Windows version, application archive SHA-256, printer model/driver and results. Use sample data only and an isolated `FBPS_DATABASE_PATH`.

- [ ] On a clean Windows x64 machine without Visual Studio or a .NET SDK, extract the entire ZIP and launch `FBPS.WinForms.exe` as a normal user. Verify first-run database initialization.
- [ ] Add classes/sections and students; generate monthly tuition; collect partial and exact payments. Verify receipt identity, allocation order and rejection of overpayments.
- [ ] Close the app normally and restart it. Verify the same student IDs, charges, receipts, history, balances and configured database path. Check offline operation with networking disabled.
- [ ] Open the same database in a second FBPS instance; confirm it is blocked with a useful message.
- [ ] Reconcile dashboard, collection report, class/section status, defaulters and student ledger against known sample records. Exercise long names and high-DPI layouts.
- [ ] Use the in-app live backup feature, add another payment, restore the older backup with confirmation, and reopen the app. Verify original data, automatic pre-restore recovery backup and non-reused receipt numbers.
- [ ] Test preview, Microsoft Print to PDF and the actual school A4 printer, including cancellation/failure/retry and multi-page receipts/reports. Reprinting must not change payment counts or amounts.
- [ ] Test an upgrade from a copy of the previous release's populated database, preserving all records and receipts.
- [ ] Exercise protected/unwritable folders and a nearly-full disposable test disk. Verify understandable errors and no duplicated collection after retry. Do not fault-inject against live data.
- [ ] Complete the user workflows in `USER-MANUAL.md` and obtain school cashier/administrator sign-off.

If any financial, allocation, persistence or receipt test fails, stop deployment. Keep the database and logs, diagnose the failure and repeat the relevant checks. The Linux service-host restart test does **not** replace the Windows published-app restart check above.
