# Fee Collection

Open **Fee Collection**, search by admission number, roll number or name, select the student, and open collection. Enable **Include archived students** when settling an archived student's balance.

The screen displays identity, class/section and the latest configured monthly tuition rate. The selected month's charge comes from its historical charge record, so it can differ from the latest configured rate.

1. Select the fee month cutoff. The breakdown refreshes automatically and excludes later months.
2. Use **Generate missing charges through month** to create the complete eligible schedule using admission/archive dates and effective tuition rates. The operation requests confirmation and is idempotent. Unknown historical rates or archive dates produce an actionable error rather than invented charges.
3. Review previous unpaid arrears, the selected month's gross charge, paid-to-date allocations against eligible charges, and the total unpaid balance before collection. Only posted charges appear; the screen states this explicitly.
4. Enter actual whole-PKR cash received. The live preview shows the remaining balance. Zero, negative, fractional and excessive payments cannot be confirmed. Overpayments do not become credits or pay future months.
5. Confirm the amount, cutoff and preview. Balances are refreshed before confirmation; the service validates them again under the transaction lock before saving.
6. After commit, the screen reloads balances and payment history from the database, displays the saved receipt number and opens the existing receipt viewer. Payment history includes the stored receipt number, collection timestamp, selected cutoff and amount.

## Allocation and retry behavior

The engine orders eligible unpaid charges oldest first. September collection therefore settles July, then August, then September; October is excluded. The service checks that allocation amounts sum to the full cash received, and database triggers enforce each charge's remaining balance and the payment's remaining unallocated amount. Payment and allocations commit together, or all roll back.

`PaymentSubmission` owns one request GUID per cashier intent. Concurrent calls share one task. A failed save retains the same request and locks amount/month edits; **Retry / resolve payment** recovers the same receipt if the transaction already committed. A successful response remains cached until the database refresh succeeds. The form prevents closing with an unresolved intent. Pre-commit argument-validation rejection releases the intent so the cashier can correct the entry. Starting another payment is allowed after a successful refresh.

The pending intent is held in memory while the collection form is open. Abrupt process or machine termination does not preserve that UI state; inspect persisted payment history before initiating a new collection after restart. Database request uniqueness remains durable for retries that supply the original request ID.

## Verification

Automated tests cover partial and exact payments across July–September, October exclusion, zero/negative/overpayment rejection, allocation totals and per-charge limits, double-click coalescing, retry after a lost post-commit response, and transaction rollback followed by retry. Existing tests cover concurrent payments, database allocation caps, receipt uniqueness, filters and financial history.

Verified: **121 tests passed, 0 failed, 0 skipped**. Release solution build passed with **0 warnings and 0 errors**. WinForms was cross-compiled on Linux; interactive verification requires Windows.

Windows checks:

- Search using each supported identifier; verify displayed student/class/section.
- With PKR 1,000 charges for July–October, select September. Expect PKR 2,000 arrears, PKR 1,000 current charge and PKR 3,000 due.
- Enter PKR 1,250. Preview PKR 1,750 remaining; cancel confirmation and verify no payment. Confirm again; expect July paid, August PKR 750 outstanding, September PKR 1,000 outstanding, and October unchanged.
- Pay the remaining PKR 1,750; expect zero September balance. Reject PKR 1,751 before collection.
- Double-click confirmation; verify one payment and one receipt. Refresh/history must agree with the new balance.
- Change cutoff to August and October; verify each recalculated breakdown. Try an archived student with historical arrears.
- Resize the window and test Windows scaling at 100%, 150% and 200%; ensure labels, entry controls and both grids remain accessible.
