# Fee receipts and printing

Newly collected payments save `FeePayment.ReceiptDetailsJson` in the same transaction as the payment and allocations. The snapshot holds the student's roll, class and section plus every eligible month's original charge and paid-before amount. Existing student-name/admission snapshots, receipt number, selected fee month, timestamp and cash amount remain on `FeePayment`. Receipt allocations are always read from the saved `PaymentAllocation` records joined to their immutable monthly charges.

The snapshot is protected by the existing payment UPDATE/DELETE prevention triggers. `ReceiptSnapshots` adds a nullable column without changing older payments or rebuilding their tables. Downgrade requires a pre-upgrade backup.

`ReceiptDocument` produces presentation content without depending on Windows. For each eligible month it shows the gross charge, payments before this collection, balance before, amount allocated by this saved payment and balance after. It separately labels previous arrears, current month's gross charge, **TOTAL DUE BEFORE PAYMENT**, **AMOUNT RECEIVED (Cash)** and **REMAINING AFTER PAYMENT**. All amounts use PKR. Display totals use `BigInteger` sums to avoid overflow across individually valid 64-bit charges; stored amounts remain integer PKR.

Historical receipts created before this migration retain their original identity, receipt number and allocations. Their original class/section and before/after balances cannot be recovered reliably, because charges may have been backfilled and placement changed afterward. Those fields are explicitly marked unavailable; current balances are never substituted for historical receipt totals.

## A4 viewer

After payment commits and balances refresh, the collection screen opens `ReceiptPrintForm`. The same viewer is accessible from **Payment history → View / print selected receipt**; this path calls only `ReceiptAsync`, never collection or assessment.

The viewer uses supported Windows `PrintDocument`, `PrintDialog` and `PrintPreviewControl` APIs. It provides A4 portrait preview, page navigation, fit-page/100% zoom and print selection, including Microsoft Print to PDF. Text is measured and wrapped at printable margins; long names, notes and many allocation months flow onto further pages with receipt identifiers and page numbers. Headers and financial totals use larger bold type. There is no compact paper mode in this phase.

Preview and printing failures are logged and displayed in the viewer, which remains available for retry. Print cancellation never reports success. A successful `PrintDocument.Print()` call reports submission to the printer only; it cannot verify physical paper delivery. The viewer contains no payment-saving capability, so printing again cannot record another payment.

## Automated verification

Release solution build: **0 warnings, 0 errors**. Tests: **126 passed, 0 failed, 0 skipped**. EF reports no pending model changes.

Tests cover full, partial and multi-month payments; prior partial payments; preserved long names and notes; stable reprints after additional payments, new charges and student placement/name changes; unchanged ledger counts/balances; and explicit unknown-history behavior. Existing tests continue to cover payment rollback, retry identity, financial immutability and upgrades.

## Windows printer acceptance checks

Actual preview rendering and printer drivers require Windows; they were not executed in the Linux build environment.

1. Collect a full payment, a partial payment and a payment spanning several months. Verify each preview's distinct due/received/remaining totals against the collection screen.
2. Print each to Microsoft Print to PDF on A4. Check alignment, margins, page numbers and legibility. Test a 150-character name, a 1,000-character note (including an unbroken string), and enough monthly charges to span multiple pages. Check that no text is omitted or clipped.
3. Record another payment, edit student details, then reprint the first receipt. Verify the original identity, class/section, amounts and receipt number remain unchanged.
4. Cancel the print dialog; verify no success status. Try an unavailable printer and retry with a working printer/PDF destination. Verify one unchanged payment in history.
5. Print to the school's physical A4 printer and inspect the paper output. Check preview and printing at 100%, 150% and 200% Windows display scaling.
