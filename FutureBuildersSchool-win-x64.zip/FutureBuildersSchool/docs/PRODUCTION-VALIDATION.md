# Production preparation evidence

Status: **not yet production-approved**. This document records what was executed and the remaining acceptance gates. No financial test failed in the final run.

## Executed checks

| Check | Result |
| --- | --- |
| Complete .NET/SQLite automated suite | 144 passed, 0 failed, 0 skipped |
| Release solution build, including WinForms cross-target | 0 warnings, 0 errors |
| Self-contained Windows x64 CLI publish | Succeeded; .NET/Windows Desktop 8.0.32 included |
| Populated migrations, repeated initialization and invalid-upgrade rollback | Passed |
| Receipt uniqueness, immutable financial history, full/partial/multi-month allocations and retry tests | Passed |
| Live WAL backup and exclusion of uncommitted changes | Passed |
| Restore validation, pre-restore backup and non-reuse of receipt numbers | Passed |
| Corrupt/tampered backup rejection without replacing live data | Passed |
| Real SQLite busy/locked and SQLITE_FULL errors | Passed; actionable messages and unchanged failed writes |
| Single-instance lease and build-output database-path rejection | Passed |
| Report date boundaries, future exclusion, combined filters and N+1 read-count check | Passed |

Machine-readable results: `tests/FBPS.Tests/TestResults/production-checks.trx` (generated). The test suite uses separate temporary SQLite files and does not create sample records in a production database.

## 1,000-student scenario

The test seeded **1,000 students**, **10 classes**, **20 sections**, **3,000 monthly charges**, **600 payments**, and **900 allocations**, then disposed the application service host, cleared SQLite pools, created a new host and applied migrations twice.

After reopening:

- Every expected student, charge, payment, allocation and unique receipt persisted.
- Three months of tuition: **PKR 3,000,000**.
- Actual collected cash and allocated payments: **PKR 750,000**.
- All-history outstanding and dashboard outstanding: **PKR 2,250,000**.
- Earlier selected-month defaulters excluded the later month's PKR 1,000,000 charges and totaled **PKR 1,250,000**.
- Dashboard active students: **1,000**; current-month expected tuition: **PKR 1,000,000**; current-month actual cash: **PKR 750,000**.
- A previously saved multi-month receipt and student ledger reconciled after reopening.
- A verified backup retained all 1,000 students, 600 payments and PKR 750,000 cash.

This exercises database/service persistence and batch behavior. It is not an interactive 1,000-row WinForms performance benchmark or an actual Windows process-restart test.

## Remaining limitations and gates

- No Windows execution environment or Visual Studio GUI is available here. The Windows artifact was cross-published via .NET CLI using the checked-in Visual Studio profile. Clean-Windows execution, GUI restart/restore, usability/DPI and physical printing remain untested.
- Printer submission can be reported, but physical delivery cannot be verified by the app. Printer failures must be retried from the saved receipt, not as another payment.
- Backup validation accepts the current schema and matching protection triggers, and rejects inconsistent payment/allocation totals. Older schema backups require a supervised version-matched recovery/upgrade. A damaged live database that cannot produce a verified pre-restore backup requires supervised offline recovery rather than bypassing the guard.
- Restore intentionally replaces active records with the chosen snapshot. Later records are retained in the automatic pre-restore backup, not merged. Receipt high-water preservation prevents reusing numbers from the replaced data; gaps are normal.
- No reversals/refunds, reconciliation adjustments, role-based login, backup encryption, automatic off-device backup, installer, code signing or updater are implemented. Access to database/backups must be controlled by Windows account/folder permissions and school procedures.
- Pending cashier retry IDs are preserved while the collection form is open, not across abrupt process loss. Inspect persisted history before initiating another collection after a crash.
- Legacy receipts without historical snapshots identify unknown class/section and original balances explicitly. Historical tuition-rate/archive-date gaps must be supplied before assessment generation. Reports flag missing assessments rather than inventing debt.
- The entire repository is currently untracked in this workspace; no commit, PR or release publication was requested or performed. Preserve the source, release artifact, verified backups and acceptance record under the school's release process.

Complete `DEPLOYMENT.md` and `WINDOWS-CHECKLIST.md` on the target Windows environment before approving production use.
