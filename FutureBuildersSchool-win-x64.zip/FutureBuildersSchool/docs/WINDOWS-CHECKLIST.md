# Windows acceptance checks

Use the [student module CRUD checklist](STUDENT-MODULE.md) for the detailed Add, View, Edit, Search/Filter, Archive and DPI scenarios.

The Linux cloud environment can compile the Windows target and run SQLite service tests, but cannot open WinForms or drive Windows printers. Complete these checks on Windows before live use.

Use a separate test database configured outside the application directory.

1. Launch from Visual Studio 2022 or the self-contained Windows publish folder. Verify first-run initialization and restart persistence.
2. Add a class and section, then add two students. Search by name and admission number, edit a student's monthly tuition and section, and confirm validation errors for duplicates, blank names and negative/fractional PKR.
3. Generate two consecutive tuition months at PKR 1,000 each for a student. Generate one again; verify no duplicate due appears.
4. Collect PKR 1,250. Verify the older month has zero balance and the second has PKR 750 remaining. Attempt PKR 751; verify rejection. Collect PKR 750 and verify a zero balance.
5. View payment history; reprint the first receipt after editing the student's name. Verify the original name and PKR 1,250 receipt total remain.
6. Print a receipt to Microsoft Print to PDF and a physical school printer. Check margins, readability, PKR labels and local collection time. Print a report spanning several pages; verify page numbers and no missing lines.
7. Exercise class, section, student and tuition-month filters separately and together. Change a filter and confirm stale results cannot be printed. Verify arrears and paid-to-date meanings against the displayed explanations.
8. Archive a student with outstanding dues. Verify the student disappears from the default list, remains visible with Include archived, receives no charges after its archive month, and can still settle old dues.
9. Restart the app, then disconnect Internet access. Repeat search, assessment, collection, receipt reprint and reporting.
10. Test display scaling at 100%, 125%, and 150%, keyboard navigation, and long student names. Confirm operation errors are readable and written to the Logs folder.
11. Use Backup / Restore to create and validate a live backup. Add another payment, restore the older backup with confirmation, and restart the app. Verify restored students/balances/receipts, the pre-restore recovery backup, and that the next receipt does not reuse a previously issued number.
12. Confirm a second application instance cannot open the same database. Follow [the clean-Windows deployment gate](DEPLOYMENT.md) and record sign-off before live use.

Do not use live school records for these checks. The initial implementation has no payment reversal or assessed-dues correction UI; validate entry procedures before production use.
