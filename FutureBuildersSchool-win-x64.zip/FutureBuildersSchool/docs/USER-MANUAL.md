# Future Builders Public School — quick user manual

All money is whole PKR. Use the Windows **Pakistan Standard Time** timezone. Normal school work runs offline. Follow the deployment acceptance checklist before entering live records.

## Add students

1. Open **Students → Class / section setup** and create the school's classes/sections if needed.
2. Choose **Add Student**. Enter admission number, roll number, name, father's name, contact, class, section, monthly tuition and admission date.
3. Save, then use Search or View to verify the record. Admission numbers and rolls within class/section must be unique, including archived students.
4. Use Edit for corrections. Ordinary tuition-rate edits take effect next month; existing charges never change. Use Archive to retain a departing student's financial history. The archive month remains chargeable; later months do not.

## Collect tuition

1. Open **Fee Collection**, search by admission number, roll or name, and open the selected student. Check identity and placement.
2. Select the fee month cutoff. Use **Generate missing charges through month** to complete eligible assessments using dated rates. Full tuition applies in admission and archive months.
3. Check previous arrears, current charge, paid-to-date and remaining balance. September includes unpaid eligible July/August charges, but excludes October.
4. Enter the cash actually received. Review the preview and confirm once. Payments settle oldest eligible charges first. Overpayments, zero, negative and fractional payments are rejected.
5. After saving, confirm the receipt number and refreshed balance. If a save fails, use **Retry / resolve payment** without changing details; do not record it again as a new payment. If the computer restarts unexpectedly, inspect payment history before attempting any new collection.

## Print and reprint receipts

After collection, use the A4 receipt viewer's preview and **Print…** button. Choose the school printer or Microsoft Print to PDF. To reprint, select the saved payment in **Payment history → View / print selected receipt**. Reprinting does not collect money again.

If printing fails, correct the printer problem and retry printing the saved receipt. A message saying the document was submitted to the printer does not prove paper delivery; check the output. Older receipts without stored historical balance details identify those fields as unavailable.

## Check arrears and reports

- **Class / Section Fee Status:** choose class/section and fee month; review paid allocations and outstanding amounts. Missing assessments are flagged, not treated as Paid.
- **Defaulters:** lists positive eligible balances through the selected month, including archived debt.
- **Monthly Collection Report:** reports actual cash by collection date; its fee-month column is a separate value.
- **Student Ledger:** select a student. The cutoff summary excludes future charges; the explicitly labelled all-history ledger includes them. Lifetime cash is not the current outstanding amount.

Generate missing assessments before relying on reports as the complete receivables schedule. Run again after changing filters. Preview/print or export the loaded report if required.

## Back up every working day

1. Open **Backup / Restore → Create verified backup…**.
2. Choose a new dated `.db` filename, preferably on a protected separate drive. Existing backups cannot be overwritten.
3. Wait for **Verified backup saved** and check its student/payment counts. The app uses SQLite's backup API, including committed WAL data; never manually copy a live database and assume it is complete.
4. Keep several dated copies and an off-device copy. Protect access: backups contain student and financial records. Use **Validate backup…** to check a saved copy.

A backup written on the same disk protects against some mistakes, not failure of that disk. Copy the completed standalone backup to another protected device; do not copy the live database's WAL files while the app is running.

## Restore — administrator only

1. Stop school data entry and close external database tools. Ensure enough free space for a staged restore and a full pre-restore backup. Only one FBPS instance may use a database.
2. Open **Backup / Restore → Restore database…**, select the verified backup, and review its counts.
3. Read the confirmation: restoration replaces current data. Records added after the backup will disappear from the active database. They remain in the automatic pre-restore backup.
4. Confirm only if this replacement is intended. The application validates the staged backup, creates and verifies a pre-restore backup beside the live database, then restores transactionally. If validation or pre-backup fails, replacement does not begin.
5. Note the pre-restore backup filename. FBPS closes after successful restore. Reopen it and verify students, latest receipts, dashboard and reports before collecting more fees. Receipt numbering advances beyond numbers issued before the restore, leaving intentional gaps.

Restore accepts the same schema version as the installation. For an older-version backup, contact support to open/upgrade a copy with the appropriate release. If the live database is too damaged to create a verified pre-restore backup, do not delete it or bypass validation; preserve the entire folder and obtain supervised offline recovery.

## Errors and support

- **Busy/locked:** close other database tools and retry the same operation.
- **Disk full/write error:** free space and check the drive/folder. Do not delete `school.db`, its WAL/SHM files or payment records.
- **Invalid backup/integrity error:** retain existing files and use another verified backup or contact support.
- **Unexpected transaction error:** no success should be assumed. Resolve the existing payment request before collecting again.

Logs: `%LOCALAPPDATA%\FutureBuildersPublicSchool\Logs`. Default database: `%LOCALAPPDATA%\FutureBuildersPublicSchool\school.db`. These are separate from the application installation and build folders.
