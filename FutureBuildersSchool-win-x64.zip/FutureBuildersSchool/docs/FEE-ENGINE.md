# Monthly tuition calculation engine

The engine is independent of WinForms. Contracts and result records live in `FBPS.Application/FeeCalculations.cs`; `FeeCalculationService` and `TuitionRateService` live in Infrastructure. No new UI or printing code is included in this phase. The existing dashboard service now uses effective rates rather than a future scheduled profile rate.

## Formulas and selected-month meaning

For every stored charge in month `m`:

```text
MonthlyCharge(m) = the immutable TuitionAmount for that student/month
AmountPaidAllocatedToThatMonth(m) = sum of allocations linked to that charge
OutstandingForThatMonth(m) = MonthlyCharge(m) − AmountPaidAllocatedToThatMonth(m)

PreviousArrears(M) = sum of OutstandingForThatMonth(m) where m < M
CurrentMonthFee(M) = MonthlyCharge(M)
TotalDueThroughSelectedMonth(M) = PreviousArrears(M) + OutstandingForThatMonth(M)
```

`CurrentMonthFee` is the gross selected-month charge; the total uses its **unpaid** portion. A missing selected-month charge contributes zero and sets `HasSelectedMonthCharge=false`. Read methods use posted charges only: call charge generation first when a complete eligible schedule is required. No read method silently creates financial records.

Every calculation query excludes charges after `M`, including class/section summaries and allocation candidates. Allocated payments are paid-to-date, even when collected after the selected tuition month. These methods are not payment-date “as of” statements. Unallocated receipts do not reduce charges.

Example: January tuition PKR 1,000, February tuition PKR 1,000, and PKR 1,250 allocated oldest first give February arrears **0**, current charge **1,000**, current allocated **250**, current outstanding **750**, and total due **750**. A March charge does not affect February's result.

## Eligibility and history

- Full tuition applies in the admission month, even for admission on its last day. No proration or rounding occurs.
- `ArchivedOn` records the last eligible date. Its month is charged in full; later months are excluded. Archive dates must fall between admission and today. Already-issued charges cannot be invalidated by moving admission forward or archiving earlier. Recorded archive dates are immutable; re-enrollment and financial reversals are outside this phase.
- Archived students retain all balances and may pay them. Generation can backfill missing charges from eligible months, including the archive month, even after archive.
- New students receive an initial immutable rate at the first day of their admission month. Later rates are effective from explicit first-of-month dates, until the next rate entry. Ordinary student-profile edits default to the next local calendar month; `StudentInput.TuitionEffectiveMonth` permits an explicit month.
- `Student.MonthlyTuitionFee` is the latest configured rate for profile display. Calculations never use that cache to infer old amounts. The effective history is authoritative.
- Inserting the same rate/effective month is idempotent. A different rate at an existing effective month is rejected. A new dated rate that would disagree with an already-issued charge in its effective interval is rejected. Charges and rate records cannot be updated/deleted.
- An explicitly supplied earlier rate may fill a historical gap, provided it agrees with all issued charges in its interval. Profile values update only when the new rate is the latest scheduled rate.
- Each charge snapshots class/section at generation time. Class/section summaries filter those snapshots with AND semantics and include archived balances. No historical placement is inferred for missing charges.

The migration preserves every existing financial record. It seeds the known profile rate from the later of migration month, admission month, or the month after the latest charge. It does not invent past rates or archive dates. Generation reports unknown historical rates or archive dates and rolls back the whole operation. Supply verified dated rates with `ITuitionRateService.SetRateAsync` and a legacy archive date with `IStudentService.ArchiveAsync(id, date)` before retrying.

## APIs and transaction boundaries

```csharp
var month = new DateOnly(2026, 2, 1);
await rates.SetRateAsync(studentId, new DateOnly(2026, 3, 1), 1500L);
await calculations.EnsureMonthlyChargesThroughAsync(month, studentId);
var breakdown = await calculations.GetStudentMonthlyBreakdownAsync(studentId, month);
var dues = await calculations.GetDuesThroughMonthAsync(studentId, month);
var summary = await calculations.GetClassSectionSummaryDuesAsync(month, classId, sectionId);
var candidates = await calculations.GetUnpaidChargesEligibleForAllocationAsync(studentId, month);
```

Omitting student ID from generation processes all students, including eligible archived periods. The selected month is an upper bound; eligibility can shorten it. An all-student operation is atomic: one unresolved history prevents a partial batch. The existing `IFeeService.AssessMonthAsync` remains an exact-month, active-student compatibility action; it shares the engine's effective-rate and eligibility logic.

Generation obtains a serializable/immediate SQLite transaction before reading rates and existing charges, creates only missing eligible months, and commits once. Unique `(StudentId, FeeMonth)` remains the final duplicate guard. Rate changes, student edits with rate history, and archive updates also use transactions.

Allocation candidates are an advisory read, sorted oldest first. Payment collection re-reads balances using the same query logic **inside its own immediate transaction**, checks retry identity, and inserts payment plus allocations atomically. Database triggers cap each allocation against both the payment's unallocated amount and the charge's outstanding balance, enforce student identity and selected-month cutoff, and prevent later ledger mutation. A retry with the same request GUID and details returns the same receipt.

## Integer money and failures

All stored money and service inputs use signed 64-bit integer PKR. No decimal conversion, prorating or floating-point arithmetic occurs. `FeeRules.ParsePkr` rejects fractional, negative, nonnumeric and out-of-range strings; zero tuition is allowed, zero payments are not. Individual balances are validated before subtraction; checked arithmetic and LINQ integer sums throw `OverflowException` if a total exceeds `long.MaxValue`. A small valid payment can still be allocated across charges whose combined total exceeds that limit because allocation consumes the requested amount without first summing the entire ledger.

Validation failures do not write partial financial records. Unexpected database failures roll back transactions. Services log successful generation, rate changes, student updates and collections using record IDs.

## Verification

Run:

```sh
dotnet build FBPS.sln -c Release --no-restore
dotnet test tests/FBPS.Tests/FBPS.Tests.csproj -c Release --no-build --logger 'trx;LogFileName=fee-engine-tests.trx'
dotnet ef migrations has-pending-model-changes --project src/FBPS.Infrastructure --configuration Release --no-build
```

Each integration fixture uses its own temporary file-backed SQLite database with migrations and foreign keys enabled, disposed after the test. Tests cover no arrears, one/multiple unpaid months, partial and full payments, future-charge exclusion, duplicate/concurrent generation, rate changes and late backfill, midyear admission, archive cutoff and historical settlement, class/section snapshots, missing-history rollback, payment rollback/retries/concurrency, direct database constraints, integer overflow, fractional input rejection, zero tuition and December 9999 boundaries. Profile rate scheduling and dashboard effective rates are tested using a fixed clock. Existing tests retain the 1,000-student assessment and populated-migration checks.

Verified in the Linux cloud workspace on 2026-10-20 with .NET SDK 8.0.426:

| Check | Result |
| --- | --- |
| Release solution build, including Windows cross-target | Passed; 0 warnings, 0 errors |
| Unit and SQLite integration tests | 113 passed, 0 failed, 0 skipped |
| EF migration/model consistency | No pending model changes |

The machine-readable run is `tests/FBPS.Tests/TestResults/fee-engine-tests.trx` (generated/ignored). Windows UI execution was not part of this engine phase.
