# Fee reports

Open **Fee Reports** and choose a report. Changing any filter clears the loaded results and disables export/preview until **Run report** is used again. Student search matches admission number, roll number or name (father's name is also supported by the existing search service). Choose a matching student, or clear search and choose all students for class-wide reports.

All reports are read-only. They do not generate assessments, collect payments, modify allocations or change receipt numbers. Amounts are whole PKR. No audited reversal/void feature exists; all saved receipts count as collected cash.

## Monthly Collection Report

Choose a calendar month, or uncheck **Calendar collection month** and enter an inclusive payment date range. The service converts local midnight boundaries to UTC and queries `start <= PaymentDate < midnight after end date`. Set the school workstation timezone to Pakistan Standard Time.

Rows show the saved receipt number, actual collection timestamp, saved student identity, selected fee-month cutoff and cash received. Payment count is the number of receipts; cash total sums `FeePayment.AmountReceived` exactly once per receipt, regardless of the number of allocations. The fee month is explicitly separate from collection date. Class/section/student filters are disabled for this report, whose supported filter is payment date.

## Class and Section Fee Status

Select current class, section, optional student and fee-month cutoff. Filters combine with AND. Every active student in the selected cohort appears, including students without posted assessments. Existing eligible debt follows the student into their current cohort, even if the charges were assessed in a former class. This is a current-student report, not an assessment-placement report.

Columns show current month's gross charge, previous unpaid arrears, gross charges through cutoff, paid-to-date allocations through cutoff and total unpaid balance. **Total due through the selected month and remaining balance are the same unpaid amount**; do not subtract paid allocations from that amount again.

```text
Remaining = eligible posted charges through cutoff − allocations against those charges
Previous arrears = remaining balances on eligible charges before cutoff
```

Statuses:

- **Paid:** eligible posted charges are fully settled and no eligible assessment months are missing. A fully assessed zero-tuition student is also Paid.
- **Partially Paid:** positive outstanding balance and some allocated payment through cutoff.
- **Unpaid:** positive outstanding balance and no allocated payment through cutoff.
- **Not Yet Due / Not Applicable:** no eligible month exists through cutoff.
- **Not Yet Assessed:** zero posted debt but eligible assessment months are missing. Missing assessments are also flagged independently for students who have some posted debt.

A payment record alone never marks a student paid. Allocations are the source of truth. Later collections allocated to an earlier fee month count as paid-to-date; this is not a payment-date historical statement.

## Student Ledger

Find and select one student. Class/section filters are disabled because the ledger includes the student's entire history.

The **selected-month summary** shows previous arrears, current charge and outstanding through the cutoff, using the same stored-charge calculation logic. It flags a missing selected-month charge. The **all-history ledger** separately displays all monthly charges, saved cash receipts, payment allocations, receipt identifiers and a running balance. Its totals label all-history charges, allocated payments, outstanding and lifetime cash collected separately.

Cash receipt rows are informational: they do not reduce debt a second time. Only allocation rows reduce the running balance. Unallocated cash receipts, if present in legacy data, remain visible and count toward lifetime cash, but do not reduce tuition balances.

Chronology uses fee-month start for charges and actual payment timestamps for receipts/allocations, with deterministic tie ordering. Charge issuance timestamps were not stored, so this is a fee-effective chronology, not a posting-time audit. A payment made early against a future fee month may show an interim credit before that month's charge; the final balance still reconciles. The all-history view intentionally includes future charges; the separate selected-month summary excludes them.

## Defaulters Report

Uses the same current class/section/student filters and cutoff rules as fee status, but keeps only positive eligible balances. Both active students and archived students with eligible historical debt are included. Admission and archive months are inclusive; future charges and periods outside known eligibility are excluded. Legacy archived records with unknown archive dates retain their posted historical debt and show the missing-history flag; no dates or amounts are invented.

Reports operate on posted charges. Generate missing eligible assessments using Fee Collection before treating these reports as the complete school receivables schedule. No report silently creates missing charges.

## Printing and CSV

**Preview / print** opens the shared A4 document viewer. Printed reports contain school name, report title, filters, totals, generated timestamp, labelled rows and page numbers. Long rows wrap across pages rather than squeezing a wide grid onto paper. Printer errors allow retry without any financial write. Successful submission is distinguished from physical delivery, which the application cannot verify.

CSV exports the loaded snapshot, including report/filter metadata and totals. UTF-8 with BOM preserves names; every field is quoted, quotes are doubled, embedded newlines are retained, and formula-like spreadsheet cells are prefixed with an apostrophe. Negative numeric cells may therefore import as safe text. Export writes a temporary file and replaces the destination only after writing succeeds. Filter changes require rerunning before exporting.

## Verification

Verified Release solution build: **0 warnings, 0 errors**. Full automated suite: **138 passed, 0 failed, 0 skipped**. Latest machine-readable output: `tests/FBPS.Tests/TestResults/fee-report-tests.trx`.

New tests cover local date/month boundaries, empty date ranges, receipt counts/cash totals, combined class/section/student filters, partial/full/unpaid statuses, admission and archive eligibility, missing assessments, zero tuition, future exclusion, ledger reconciliation, unassessed empty ledgers and CSV escaping/formula protection. A command interceptor verifies that a 50-student status report uses exactly **two set-based SQL reads**, not per-student queries. Multi-query reports read within one database transaction for consistency.

Windows acceptance checks remain necessary for interactive UI, preview and physical printing:

1. Verify calendar-month and custom-date collections against payment history, including a payment for an earlier fee month.
2. Run class/section status for unpaid, partly paid, fully paid, future-admission and unassessed students. Try incompatible class/section/student combinations and verify an empty result.
3. Confirm a transferred student's older debt is included under their current class. Confirm archived debt appears only in defaulters, not the active-status cohort.
4. Select an earlier month with later charges present; compare its summary and defaulters with the clearly separate all-history ledger.
5. Preview and print multi-page reports to Microsoft Print to PDF and an A4 printer; test long names, scaling and printer failure/retry.
6. Export CSV with commas, quotes and non-Latin names, open it in the school's spreadsheet program, and verify totals and formula neutralization. Confirm payment/charge counts are unchanged.
